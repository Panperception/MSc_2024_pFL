import torch
import tqdm
from tqdm import *
from copy import deepcopy

from fl_struct.maintainer import *
from fl_struct.helpful_scripts import *

# The server handler in the Ditto algorithm
class DittoServerHandler(SyncServerHandler):
    None

# The client trainer in the Ditto algorithm
class DittoSerialClientTrainer(SGDSerialClientTrainer):
    # Initialize the trainer with the model, num, cuda, device, logger, and personal
    def __init__(self, model, num, cuda=False, device=None, logger=None, personal=True) -> None:
        super().__init__(model, num, cuda, device, logger, personal)
        # Initialize the global and local models
        self.ditto_gmodels = []
        self.local_models = self.parameters

    # Setup the dataset
    def setup_dataset(self, dataset):
        return super().setup_dataset(dataset)

    # Setup the optimizer
    def setup_optim(self, epochs, batch_size, lr):
        return super().setup_optim(epochs, batch_size, lr)

    # Perform local computations for each client
    def local_process(self, payload, id_list):
        global_model = payload[0]
        for id in tqdm(id_list):
            # Get the data loader for the given client
            train_loader = self.dataset.get_dataloader(id, batch_size=self.batch_size)
            # Train the model and cache the results
            self.local_models[id], glb_model  = self.train(global_model, self.local_models[id], train_loader)
            self.ditto_gmodels.append(deepcopy(glb_model))

    # Prepare the model parameters to be sent back to the server
    @property
    def uplink_package(self):
        ditto_gmodels = deepcopy(self.ditto_gmodels)
        self.ditto_gmodels = []
        return [[parameter] for parameter in ditto_gmodels]

    # Train the model for each client
    def train(self, global_model_parameters, local_model_parameters, train_loader):
        criterion = torch.nn.CrossEntropyLoss()
        SerializationTool.deserialize_model(self._model, global_model_parameters)
        self._model.train()
        # Training process for the global model
        for ep in range(self.epochs):
            for data, label in train_loader:
                if self.cuda:
                    data, label = data.cuda(self.device), label.cuda(self.device)

                preds = self._model(data)
                loss = criterion(preds,label)
                self.optimizer.zero_grad()
                loss.backward()
                self.optimizer.step()

        updated_glb_models = deepcopy(self.model_parameters)

        frz_model = deepcopy(self._model)
        SerializationTool.deserialize_model(frz_model, global_model_parameters)

        SerializationTool.deserialize_model(self._model, local_model_parameters)
        criterion = torch.nn.CrossEntropyLoss()
        optimizer = torch.optim.SGD(self._model.parameters(), lr=self.lr)

        # Training process for the local model
        self._model.train()
        for ep in range(self.epochs):
            for data, label in train_loader:
                if self.cuda:
                    data, label = data.cuda(self.device), label.cuda(self.device)

                preds = self._model(data)
                l1 = criterion(preds,label)
                l2 = 0.0
                # Add the proximal term
                for w0, w in zip(frz_model.parameters(), self._model.parameters()):
                    l2 += torch.sum(torch.pow(w - w0, 2))

                # The final loss is the sum of l1 and the proximal term
                loss = l1 + 0.3 * 0.1 * l2
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()
        return self.model_parameters, updated_glb_models