from fl_struct.maintainer import *
from fl_struct.helpful_scripts import *

# The server handler in the FedAvg algorithm
class FedAvgServerHandler(SyncServerHandler):
    # Update the global model parameters on the server
    def global_update(self, buffer):
        # Extract the model parameters and weights (data sizes) from the buffer
        parameters_list = [ele[0] for ele in buffer]
        weights = [ele[1] for ele in buffer]
        # Perform federated averaging on the parameters
        serialized_parameters = Aggregators.fedavg_aggregate(parameters_list, weights)
        # Deserialize the averaged parameters and set the new model
        SerializationTool.deserialize_model(self._model, serialized_parameters)

# The client trainer in the FedAvg algorithm
class FedAvgSerialClientTrainer(SGDSerialClientTrainer):
    # Train the model for each client
    def train(self, model_parameters, train_loader):
        # Set the initial model parameters
        self.set_model(model_parameters)
        # Set the model to training mode
        self._model.train()

        # Initialize the total data size
        data_size = 0
        # Perform training over the specified number of epochs
        for _ in range(self.epochs):
            for batch_idx, (data, target) in enumerate(train_loader):
                if self.cuda:
                    # Move the data and target to GPU if available
                    data = data.cuda(self.device)
                    target = target.cuda(self.device)

                # Forward pass and compute the loss
                output = self.model(data)
                loss = self.criterion(output, target)

                # Accumulate the total data size
                data_size += len(target)

                # Zero the gradients, perform backpropagation and update the model parameters
                self.optimizer.zero_grad()
                loss.backward()
                self.optimizer.step()

        # Return the updated model parameters and the total data size
        return [self.model_parameters, data_size]