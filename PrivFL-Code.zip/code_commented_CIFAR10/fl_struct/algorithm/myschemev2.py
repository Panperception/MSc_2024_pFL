from fl_struct.maintainer import *
from fl_struct.helpful_scripts import *
from Pyfhel import Pyfhel

# Custom server handler for this specific application
class CustomServerHandler(SyncServerHandler):
    def __init__(
        self,
        model: torch.nn.Module,
        global_round: int,
        num_clients: int = 0,
        sample_ratio: float = 1,
        cuda: bool = False,
        device=None,
        sampler=None,
    ):
        super(SyncServerHandler, self).__init__(model, cuda, device)

        assert 0.0 <= sample_ratio <= 1.0

        self.num_clients = num_clients
        self.sample_ratio = sample_ratio
        self.sampler = sampler
        self.model_params = SerializationTool.serialize_model(self._model)

        # Calculate the number of clients to be used in each round
        self.round_clients = max(
            1, int(self.sample_ratio * self.num_clients)
        ) 
        self.client_buffer_cache = []

        self.global_round = global_round
        self.round = 0
    
    # Get model parameters for downlink transmission
    @property
    def downlink_package(self) -> List[torch.Tensor]:
        return [self.model_params]

    # Get number of clients per round
    @property
    def num_clients_per_round(self):
        return self.round_clients

    # Check if the server should stop
    @property
    def if_stop(self):
        return self.round >= self.global_round

    # Sample clients
    def sample_clients(self, num_to_sample=None):
        if self.sampler is None:
            self.sampler = RandomSampler(self.num_clients)

        num_to_sample = self.round_clients if num_to_sample is None else num_to_sample
        sampled = self.sampler.sample(self.round_clients)
        self.round_clients = len(sampled)

        assert self.num_clients_per_round == len(sampled)
        return sorted(sampled)

    # Update the global model with the aggregated parameters
    def global_update(self, parameters_list):
        serialized_parameters = Aggregators.partitioned_fedavg_aggregate(parameters_list)
        self.model_params = serialized_parameters

    # Load the client's models, aggregate them and update the global model
    def load(self, payload: List[torch.Tensor]) -> bool:
        assert len(payload) > 0
        self.client_buffer_cache.append(deepcopy(payload))

        assert len(self.client_buffer_cache) <= self.num_clients_per_round

        if len(self.client_buffer_cache) == self.num_clients_per_round:
            self.global_update(self.client_buffer_cache)
            self.round += 1

            self.client_buffer_cache = []

            return True 
        else:
            return False

# Custom client trainer for the application, inherits from SGDSerialClientTrainer
class CustomSerialClientTrainer(SGDSerialClientTrainer):
    # Initialize the trainer with the model, number of clients, CUDA, device, logger, and personal flag
    def __init__(self, model, num_clients, cuda=False, device=None, logger=None, personal=False) -> None:
        super().__init__(model, num_clients, cuda, device, logger, personal)
        self.local_layers = ['fc2']   # Define the local layers for customization
        self.global_model_params = None
        # Use ckks to perform he
        self.HE = Pyfhel()
        self.ckks_params = {
            'scheme': 'CKKS',  
            'n': 2**14,         
            'scale': 2**30,   
            'qi_sizes': [60, 30, 30, 30, 60]
        }
        self.HE.contextGen(**self.ckks_params)
        self.HE.keyGen()
        self.HE.rotateKeyGen()
        self.is_encrypt = False
        
    @property
    def uplink_package(self):
        package = deepcopy(self.cache)
        self.cache = []
        he_package = []
        for [params] in package:
            he_param_list = []
            np_params = params.numpy().astype(np.float64)
            start_index = 0
            slice_length = 4000
            while start_index < len(np_params):
                end_index = start_index + slice_length
                he_param_sliced = self.HE.encryptPtxt(self.HE.encodeFrac(np_params[start_index:min(end_index, len(np_params))]))
                start_index += slice_length
                he_param_list.append(he_param_sliced)
              
            he_package.append(he_param_list)
        self.is_encrypt = True
        return he_package
    
    # Local processing for each client
    def local_process(self, payload, id_list):
        he_model_parameters = payload[0]
        for id in (progress_bar := tqdm(id_list)):
            progress_bar.set_description(f"Training on client {id}", refresh=True)
            data_loader = self.dataset.get_dataloader(id, self.batch_size)
            if self.is_encrypt:
                he_param_list = he_model_parameters
                ori_params = np.concatenate([self.HE.decryptFrac(he_params) for he_params in he_param_list])
                model_parameters = torch.from_numpy(np.round(ori_params, decimals=4))
            else:
                model_parameters = he_model_parameters
            pack = self.train(model_parameters, data_loader)
            self.cache.append(pack)
    
    # Method to get the ensemble model
    def get_ensemble_model(self, global_model_parameters):
        state_dict = self._model.state_dict()
        global_model = deepcopy(self._model)
        SerializationTool.deserialize_model(global_model, global_model_parameters)
        
        # Assign global model parameters to the ensemble model
        for name, _ in global_model.named_parameters():
            is_local = False
            for local_layer in self.local_layers:
                if local_layer in name:
                    is_local = True
                    break
            if not is_local:
                state_dict[name] = global_model.state_dict()[name]
                
        self._model.load_state_dict(state_dict)
        
    # Prepare local part of the model
    def prepare_local_part(self):
        for name, param in self._model.named_parameters():
            is_local = any(local_layer in name for local_layer in self.local_layers)
            param.requires_grad = is_local
                
    # Prepare global part of the model
    def prepare_global_part(self):
        for name, param in self._model.named_parameters():
            is_local = any(local_layer in name for local_layer in self.local_layers)
            param.requires_grad = not is_local
    
    # Train the model
    def train(self, global_model_parameters, train_loader):
        self.cuda = False
        # Backup original model parameters
        backup_model_params = deepcopy(self.model_parameters)
        backup_model = deepcopy(self._model)
        SerializationTool.deserialize_model(backup_model, backup_model_params)

        # Get first 2 layers of global model
        self.get_ensemble_model(global_model_parameters)

        # Train global part of the model
        self.prepare_global_part()
        global_optimizer = torch.optim.SGD(filter(lambda p: p.requires_grad, self._model.parameters()), lr=self.lr)
        self._model.train()
        for _ in range(self.epochs):
            for data, label in train_loader:
                if self.cuda:
                    data, label = data.cuda(self.device), label.cuda(self.device)

                preds = self._model(data)
                loss = self.criterion(preds,label)
                global_optimizer.zero_grad()
                loss.backward()
                global_optimizer.step()
                
        updated_glb_model_params = deepcopy(self.model_parameters)
        
        # Load the backup model
        SerializationTool.deserialize_model(self._model, backup_model_params)

        # Train local part of the model
        self.prepare_local_part()
        local_optimizer = torch.optim.SGD(filter(lambda p: p.requires_grad, self._model.parameters()), lr=self.lr)
        self._model.train()
        for _ in range(self.epochs):
            for data, label in train_loader:
                if self.cuda:
                    data, label = data.cuda(self.device), label.cuda(self.device)

                preds = self._model(data)
                l1 = self.criterion(preds,label)
                l2 = 0.0
                
                # Calculate the loss for the local part
                # Calculate the loss for the local part
                for (name, w), w_g in zip(self._model.named_parameters(), backup_model.parameters()):
                    is_local = any(local_layer in name for local_layer in self.local_layers)
                    if not is_local:
                        l2 += torch.sum(torch.pow(w - w_g, 2))

                # loss = l1 + 0.1 * l2
                loss = l1
                local_optimizer.zero_grad()
                loss.backward()
                local_optimizer.step()
        
        return [updated_glb_model_params]