from copy import deepcopy
from tqdm import tqdm
import torch

from fl_struct.maintainer import *

# The server handler in the FedProx algorithm
class FedProxServerHandler(SyncServerHandler):
    None

# The client trainer in the FedProx algorithm
class FedProxSerialClientTrainer(SGDSerialClientTrainer):
    
    # Set up the optimizer and the proximal term coefficient
    def setup_optim(self, epochs, batch_size, lr, mu):
        super().setup_optim(epochs, batch_size, lr)
        self.mu = mu

    # Perform local computations for each client
    def local_process(self, payload, id_list):
        model_parameters = payload[0]
        for id in tqdm(id_list):
            # Get the data loader for the given client
            data_loader = self.dataset.get_dataloader(id, self.batch_size)
            # Train the model and cache the results
            pack = self.train(model_parameters, data_loader, self.mu)
            self.cache.append(pack)

    # Train the model for each client
    def train(self, model_parameters, train_loader, mu):

        self.set_model(model_parameters)
        # Create a deepcopy of the model for later comparison
        frz_model = deepcopy(self._model)
        frz_model.eval()

        # Perform training over the specified number of epochs
        for ep in range(self.epochs):
            self._model.train()
            for data, target in train_loader:
                if self.cuda:
                    data, target = data.cuda(self.device), target.cuda(self.device)

                # Forward pass
                preds = self._model(data)
                # Compute the loss (l1) and the proximal term (l2)
                l1 = self.criterion(preds, target)
                l2 = 0.0
                for w0, w in zip(frz_model.parameters(), self._model.parameters()):
                    l2 += torch.sum(torch.pow(w - w0, 2))

                # The final loss is the sum of l1 and the proximal term
                loss = l1 + 0.5 * mu * l2

                # Zero the gradients, perform backpropagation and update the model parameters
                self.optimizer.zero_grad()
                loss.backward()
                self.optimizer.step()

        # Return the updated model parameters
        return [self.model_parameters]