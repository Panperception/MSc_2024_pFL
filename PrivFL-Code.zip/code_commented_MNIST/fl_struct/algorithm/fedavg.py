from fl_struct.maintainer import *
from fl_struct.helpful_scripts import *

# The server handler in the FedAvg algorithm
class FedAvgServerHandler(SyncServerHandler):
    # Update the global model parameters on the server
    def global_update(self, buffer):
        # Extract the model parameters and weights (data sizes) from the buffer
        parameters_list = [ele[0] for ele in buffer]
        weights = [ele[1] for ele in buffer]
        # Perform federated averaging on the parameters
        # Here, the federated average is weighted by the size of the data contributed by each client
        serialized_parameters = Aggregators.fedavg_aggregate(parameters_list, weights)
        # Deserialize the averaged parameters and set the new model
        SerializationTool.deserialize_model(self._model, serialized_parameters)

# The client trainer in the FedAvg algorithm
class FedAvgSerialClientTrainer(SGDSerialClientTrainer):
    # Train the model for each client
    def train(self, model_parameters, train_loader):
        # Set the initial model parameters
        self.set_model(model_parameters)
        # Set the model to training mode
        self._model.train()

        # Initialize the total data size
        # This is used for weighting the client's contribution in the global model update
        data_size = 0
        # Training loop: Perform training over the specified number of epochs
        for _ in range(self.epochs):
            for batch_idx, (data, target) in enumerate(train_loader):
                if self.cuda:
                    # If CUDA is enabled, move the data and target variables to the GPU
                    data = data.cuda(self.device)
                    target = target.cuda(self.device)

                # Forward pass: Compute the model output
                output = self.model(data)
                # Compute the loss using the criterion (e.g., CrossEntropy)
                loss = self.criterion(output, target)

                # Update the total data size (used for federated averaging)
                data_size += len(target)

                # Zero the gradients, perform backpropagation and update the model parameters
                self.optimizer.zero_grad()
                loss.backward()
                self.optimizer.step()

        # Return the updated model parameters and the total data size
        # The total data size is used for federated averaging on the server side
        return [self.model_parameters, data_size]