# Import required modules
import torch # PyTorch for tensor operations and deep learning
import tqdm # Progress bar library
from tqdm import * # Import all functions/classes from tqdm for progress bars
from copy import deepcopy # For deep copy functionality

# Import custom modules
from fl_struct.maintainer import * # Import all the functionalities from maintainer module
from fl_struct.helpful_scripts import * # Import all the functionalities from helpful_scripts module

# The server handler in the Ditto algorithm
# DittoServerHandler is a class that inherits from SyncServerHandler.
# Currently, it doesn't extend or override any functionality.
class DittoServerHandler(SyncServerHandler):
    None

# The client trainer in the Ditto algorithm
# DittoSerialClientTrainer is a class for client-side training. It inherits from SGDSerialClientTrainer.
class DittoSerialClientTrainer(SGDSerialClientTrainer):
    # Initialize the trainer object.
    # model: the model to train
    # num: the number of clients (?)
    # cuda: whether to use GPU acceleration
    # device: which device to use for training (CPU/GPU)
    # logger: logging object for capturing logs
    # personal: whether to use personalized training
    def __init__(self, model, num, cuda=False, device=None, logger=None, personal=True) -> None:
        # Call the parent class's constructor
        super().__init__(model, num, cuda, device, logger, personal)
        # Initialize ditto_gmodels as an empty list. This will hold global models.
        self.ditto_gmodels = []
        # Initialize local_models to the current parameters of the model
        self.local_models = self.parameters

    # Setup the dataset for training. Calls the parent class method.
    def setup_dataset(self, dataset):
        return super().setup_dataset(dataset)

    # Setup the optimizer for training. Calls the parent class method.
    # epochs: number of training epochs
    # batch_size: size of data batches
    # lr: learning rate
    def setup_optim(self, epochs, batch_size, lr):
        return super().setup_optim(epochs, batch_size, lr)

    # Perform local computations for each client
    def local_process(self, payload, id_list):
        # Get the global model from the payload
        global_model = payload[0]
        # Loop through the list of client IDs
        for id in tqdm(id_list):
            # Get the data loader for the given client
            train_loader = self.dataset.get_dataloader(id, batch_size=self.batch_size)
            # Train the model and update both local and global parameters
            self.local_models[id], glb_model  = self.train(global_model, self.local_models[id], train_loader)
            # Deep copy the global model and append to the list of global models
            self.ditto_gmodels.append(deepcopy(glb_model))

    # Prepare the model parameters to be sent back to the server
    @property
    def uplink_package(self):
        # Deep copy the list of global models to be sent back to the server
        ditto_gmodels = deepcopy(self.ditto_gmodels)
        # Reset the list of global models
        self.ditto_gmodels = []
        # Return the package
        return [[parameter] for parameter in ditto_gmodels]

    # Train the model for each client
    def train(self, global_model_parameters, local_model_parameters, train_loader):
        # Initialize loss function
        criterion = torch.nn.CrossEntropyLoss()
        # Deserialize the global model parameters into the current model
        SerializationTool.deserialize_model(self._model, global_model_parameters)
        # Set model to training mode
        self._model.train()
        # Training process for the global model
        for ep in range(self.epochs):
            for data, label in train_loader:
                if self.cuda:
                    # Move data and labels to GPU if available
                    data, label = data.cuda(self.device), label.cuda(self.device)

                # Forward pass
                preds = self._model(data)
                # Compute loss
                loss = criterion(preds,label)
                # Zero the gradients
                self.optimizer.zero_grad()
                # Perform backpropagation
                loss.backward()
                # Update the weights
                self.optimizer.step()

        # Store the updated global model parameters
        updated_glb_models = deepcopy(self.model_parameters)

        # Create a frozen model with global parameters for proximal term calculation
        frz_model = deepcopy(self._model)
        SerializationTool.deserialize_model(frz_model, global_model_parameters)

        # Deserialize local model parameters into the current model
        SerializationTool.deserialize_model(self._model, local_model_parameters)
        # Initialize the loss function to CrossEntropyLoss
        criterion = torch.nn.CrossEntropyLoss()
        # Initialize the Stochastic Gradient Descent (SGD) optimizer with the model's parameters and learning rate
        optimizer = torch.optim.SGD(self._model.parameters(), lr=self.lr)

        # Set the model to training mode
        self._model.train()

        # Training loop for the local model
        for ep in range(self.epochs):
            # Loop through each batch in the training data loader
            for data, label in train_loader:
                # Move the data and labels to the GPU if CUDA is enabled
                if self.cuda:
                    data, label = data.cuda(self.device), label.cuda(self.device)

                # Forward pass: Compute predicted y by passing x to the model
                preds = self._model(data)
                # Compute and print the Cross-Entropy loss
                l1 = criterion(preds,label)
                # Initialize the proximal term (l2 loss) to zero
                l2 = 0.0
                # Add the proximal term
                # Compute the proximal term: Sum of squared differences between each parameter in the local and global models
                for w0, w in zip(frz_model.parameters(), self._model.parameters()):
                    l2 += torch.sum(torch.pow(w - w0, 2))

                # The final loss is the sum of l1 and the proximal term
                # The final loss is a combination of the Cross-Entropy loss and the proximal term
                # The hyperparameters 0.3 and 0.1 here may need to be tuned or passed as arguments
                loss = l1 + 0.3 * 0.1 * l2
                # Zero gradients, perform a backward pass, and update the weights
                optimizer.zero_grad() # Zero out the gradients to avoid accumulation
                loss.backward() # Perform backpropagation to compute gradients
                optimizer.step() # Update model parameters

        # Return the updated model parameters along with the updated global model
        return self.model_parameters, updated_glb_models