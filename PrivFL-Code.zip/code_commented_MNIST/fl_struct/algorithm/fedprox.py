from copy import deepcopy
from tqdm import tqdm
import torch

from fl_struct.maintainer import *

# The server handler in the FedProx algorithm
class FedProxServerHandler(SyncServerHandler):
    None # The server-side logic is handled by the superclass

# The client trainer in the FedProx algorithm
class FedProxSerialClientTrainer(SGDSerialClientTrainer):
    
    # Set up the optimizer and the proximal term coefficient (mu)
    def setup_optim(self, epochs, batch_size, lr, mu):
        # Call the parent setup
        super().setup_optim(epochs, batch_size, lr)
        # Store the proximal term coefficient
        self.mu = mu

    # Function to perform local computations on each client
    def local_process(self, payload, id_list):
        # Extract the global model parameters from the payload
        model_parameters = payload[0]
        # Iterate over the list of client IDs
        for id in tqdm(id_list):
            # Get the data loader for the given client id
            data_loader = self.dataset.get_dataloader(id, self.batch_size)
            # Train the model locally and cache the updated model parameters
            pack = self.train(model_parameters, data_loader, self.mu)
            self.cache.append(pack)

    # Function to train the model on each client
    def train(self, model_parameters, train_loader, mu):
        # Initialize the model parameters
        self.set_model(model_parameters)
        # Create a deepcopy of the model for later comparison
        frz_model = deepcopy(self._model)
        # Set the frozen model to evaluation mode
        frz_model.eval()

        # Perform training over the specified number of epochs
        for ep in range(self.epochs):
            # Set the model to training mode
            self._model.train()
            for data, target in train_loader:
                # If CUDA is available, move data to the GPU
                if self.cuda:
                    data, target = data.cuda(self.device), target.cuda(self.device)

                # Perform a forward pass
                preds = self._model(data)
                # Compute the standard loss term (l1)
                l1 = self.criterion(preds, target)
                # Initialize the proximal term (l2)
                l2 = 0.0

                # Compute the proximal term based on the difference from the initial model state
                for w0, w in zip(frz_model.parameters(), self._model.parameters()):
                    l2 += torch.sum(torch.pow(w - w0, 2))

                # Compute the final loss, combining the standard loss (l1) and the proximal term
                loss = l1 + 0.5 * mu * l2

                # Perform backpropagation
                self.optimizer.zero_grad() # Zero the gradients
                loss.backward() # Compute the gradients
                self.optimizer.step() # Update the model parameters

        # Return the updated model parameters
        return [self.model_parameters]