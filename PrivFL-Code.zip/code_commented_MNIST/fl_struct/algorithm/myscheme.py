from fl_struct.maintainer import *
from fl_struct.helpful_scripts import *
from Pyfhel import Pyfhel # For Homomorphic Encryption

# Custom server handler for this specific application
class CustomServerHandler(SyncServerHandler):
    def __init__(
        self,
        model: torch.nn.Module,
        global_round: int,
        num_clients: int = 0,
        sample_ratio: float = 1,
        cuda: bool = False,
        device=None,
        sampler=None,
    ):
        # Call the parent class's constructor
        super(SyncServerHandler, self).__init__(model, cuda, device)

        # Assert that the sample ratio is within [0, 1]
        assert 0.0 <= sample_ratio <= 1.0

        # Initialize class variables
        self.num_clients = num_clients
        self.sample_ratio = sample_ratio
        self.sampler = sampler
        self.model_params = SerializationTool.serialize_model(self._model)

        # Calculate the number of clients to be used in each round
        self.round_clients = max(
            1, int(self.sample_ratio * self.num_clients)
        )

        # Initialize the buffer cache for client models
        self.client_buffer_cache = []

        # Initialize global and current rounds
        self.global_round = global_round
        self.round = 0
    
    # Property to get model parameters for downlink transmission to clients
    @property
    def downlink_package(self) -> List[torch.Tensor]:
        return [self.model_params]

    # Property to get the number of clients to be used in each communication round
    @property
    def num_clients_per_round(self):
        return self.round_clients

    # Property to check if the server should stop training (end global rounds)
    @property
    def if_stop(self):
        return self.round >= self.global_round

    # Sample clients
    def sample_clients(self, num_to_sample=None):
        # Initialize sampler if not provided
        if self.sampler is None:
            self.sampler = RandomSampler(self.num_clients)

        # Decide the number of clients to sample
        num_to_sample = self.round_clients if num_to_sample is None else num_to_sample
        # Sample clients
        sampled = self.sampler.sample(self.round_clients)
        # Update number of clients sampled
        self.round_clients = len(sampled)

        # Check if the number of sampled clients matches the expected count
        assert self.num_clients_per_round == len(sampled)
        # Return sorted list of sampled clients
        return sorted(sampled)

    # Update the global model with the aggregated parameters
    def global_update(self, parameters_list):
        # Aggregate the client model parameters to get a global update
        serialized_parameters = Aggregators.partitioned_fedavg_aggregate(parameters_list)
        # Update the model parameters with the aggregated parameters
        self.model_params = serialized_parameters

    # Load the client's models, aggregate them and update the global model
    def load(self, payload: List[torch.Tensor]) -> bool:
        # Ensure that payload is not empty
        assert len(payload) > 0
        # Add the incoming payload (parameters from a client) to the buffer cache
        self.client_buffer_cache.append(deepcopy(payload))

        # Check if cache size is within limit
        assert len(self.client_buffer_cache) <= self.num_clients_per_round

        # Check if we have enough client data for aggregation
        if len(self.client_buffer_cache) == self.num_clients_per_round:
            # Perform global update (aggregation) if enough client data is received
            self.global_update(self.client_buffer_cache)

            # Increment the round counter
            self.round += 1

            # Clear the cache for the next round
            self.client_buffer_cache = []

            # Indicate that the load was successful
            return True
        else:
            # Indicate that the load was not successful, as not enough client data received
            return False

# Custom client trainer for the application, inherits from SGDSerialClientTrainer
class CustomSerialClientTrainer(SGDSerialClientTrainer):
    # Initialize the trainer with the model, number of clients, CUDA, device, logger, and personal flag
    def __init__(self, model, num_clients, cuda=False, device=None, logger=None, personal=False) -> None:
        # Initialize the parent SGDSerialClientTrainer with the given parameters
        super().__init__(model, num_clients, cuda, device, logger, personal)

        # Specify layers that will be customized per client
        self.local_layers = ['fc3']
        # To store global model parameters
        self.global_model_params = None
        # Initialize Homomorphic Encryption (HE) settings
        self.HE = Pyfhel()
        self.ckks_params = {
            'scheme': 'CKKS',  
            'n': 2**14,         
            'scale': 2**30,   
            'qi_sizes': [60, 30, 30, 30, 60]
        }
        self.HE.contextGen(**self.ckks_params)
        self.HE.keyGen()
        self.HE.rotateKeyGen()

        # To track whether the model parameters are encrypted
        self.is_encrypt = False
        
    @property
    def uplink_package(self):
        # Create a deepcopy of the cache
        package = deepcopy(self.cache)
        # Clear the cache for future use
        self.cache = []
        # To store encrypted model parameters
        he_package = []

        # Encrypt model parameters and add them to he_package
        for [params] in package:
            he_param_list = []
            np_params = params.numpy().astype(np.float64)
            start_index = 0
            slice_length = 4000
            while start_index < len(np_params):
                end_index = start_index + slice_length
                he_param_sliced = self.HE.encryptPtxt(self.HE.encodeFrac(np_params[start_index:min(end_index, len(np_params))]))
                start_index += slice_length
                he_param_list.append(he_param_sliced)
              
            he_package.append(he_param_list)

        # Mark the package as encrypted
        self.is_encrypt = True
        return he_package
    
    # Perform local processing for each client
    def local_process(self, payload, id_list):
        # Retrieve encrypted model parameters from payload
        he_model_parameters = payload[0]
        for id in (progress_bar := tqdm(id_list)):
            # Set the description for the progress bar
            progress_bar.set_description(f"Training on client {id}", refresh=True)

            # Get the data loader for the client
            data_loader = self.dataset.get_dataloader(id, self.batch_size)
            if self.is_encrypt:
                he_param_list = he_model_parameters
                ori_params = np.concatenate([self.HE.decryptFrac(he_params) for he_params in he_param_list])
                model_parameters = torch.from_numpy(np.round(ori_params, decimals=4))
            else:
                model_parameters = he_model_parameters

            # Train the model on the client's data
            pack = self.train(model_parameters, data_loader)

            # Cache the trained model's parameters
            self.cache.append(pack)
    
    # Method to get an ensemble model by combining local and global parameters
    def get_ensemble_model(self, global_model_parameters):
        # Get the current state dictionary of the model
        state_dict = self._model.state_dict()

        # Create a deepcopy of the model to load global parameters
        global_model = deepcopy(self._model)
        SerializationTool.deserialize_model(global_model, global_model_parameters)
        
        # Assign global model parameters to the ensemble model
        for name, _ in global_model.named_parameters():
            # Variable to check if a layer is local or global
            is_local = False
            # Check if the layer is a local layer
            for local_layer in self.local_layers:
                if local_layer in name:
                    is_local = True
                    break

            # If the layer is global, update the ensemble model's parameters
            if not is_local:
                state_dict[name] = global_model.state_dict()[name]

        # Load the updated state_dict into the model
        self._model.load_state_dict(state_dict)
        
    # Prepare the local layers of the model for training
    def prepare_local_part(self):
        for name, param in self._model.named_parameters():
            # Check if the parameter belongs to a local layer
            is_local = any(local_layer in name for local_layer in self.local_layers)

            # Set the requires_grad attribute accordingly
            param.requires_grad = is_local
                
    # Prepare the global layers of the model for training
    def prepare_global_part(self):
        for name, param in self._model.named_parameters():
            # Check if the parameter belongs to a local layer
            is_local = any(local_layer in name for local_layer in self.local_layers)

            # Set the requires_grad attribute accordingly, opposite to the local layers
            param.requires_grad = not is_local
    
    # Method to train the ensemble model
    def train(self, global_model_parameters, train_loader):
        # Disable CUDA
        self.cuda = False

        # Backup the current model parameters and model
        backup_model_params = deepcopy(self.model_parameters)
        backup_model = deepcopy(self._model)
        SerializationTool.deserialize_model(backup_model, backup_model_params)

        # Initialize the global model parameters into the ensemble model
        self.get_ensemble_model(global_model_parameters)

        # Prepare to train only the global part of the model
        self.prepare_global_part()
        global_optimizer = torch.optim.SGD(filter(lambda p: p.requires_grad, self._model.parameters()), lr=self.lr)

        # Training loop for the global part
        self._model.train()
        for _ in range(self.epochs):
            for data, label in train_loader:
                if self.cuda:
                    data, label = data.cuda(self.device), label.cuda(self.device)

                preds = self._model(data)
                loss = self.criterion(preds,label)
                global_optimizer.zero_grad()
                loss.backward()
                global_optimizer.step()

        # Store the updated global model parameters
        updated_glb_model_params = deepcopy(self.model_parameters)
        
        # Restore the original model parameters for local training
        SerializationTool.deserialize_model(self._model, backup_model_params)

        # Prepare to train only the local part of the model
        self.prepare_local_part()
        local_optimizer = torch.optim.SGD(filter(lambda p: p.requires_grad, self._model.parameters()), lr=self.lr)

        # Training loop for the local part
        self._model.train()
        for _ in range(self.epochs):
            for data, label in train_loader:
                if self.cuda:
                    data, label = data.cuda(self.device), label.cuda(self.device)

                preds = self._model(data)
                l1 = self.criterion(preds,label)
                # Initialize l2 loss (for preserving global parameters)
                l2 = 0.0
                
                # Compute additional loss term to keep the global model parameters unchanged
                for (name, w), w_g in zip(self._model.named_parameters(), backup_model.parameters()):
                    is_local = any(local_layer in name for local_layer in self.local_layers)
                    if not is_local:
                        l2 += torch.sum(torch.pow(w - w_g, 2))

                # Total loss = local loss + 0.1 * global loss
                loss = l1 + 0.1 * l2
                local_optimizer.zero_grad()
                loss.backward()
                local_optimizer.step()
        
        return [updated_glb_model_params]